export declare const TappSdk: {
    initialize(_configurationUrl: string): void;
};
//# sourceMappingURL=TappSdk.d.ts.map