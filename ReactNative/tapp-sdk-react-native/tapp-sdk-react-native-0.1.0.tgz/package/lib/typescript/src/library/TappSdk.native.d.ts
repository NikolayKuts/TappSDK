export declare const TappSdk: {
    initialize(configurationUrl: string): void;
};
//# sourceMappingURL=TappSdk.native.d.ts.map