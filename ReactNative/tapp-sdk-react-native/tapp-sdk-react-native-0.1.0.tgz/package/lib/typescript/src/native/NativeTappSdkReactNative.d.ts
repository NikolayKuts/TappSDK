import { type TurboModule } from 'react-native';
export interface Spec extends TurboModule {
    initialize(configurationUrl: string): void;
}
declare const _default: Spec;
export default _default;
//# sourceMappingURL=NativeTappSdkReactNative.d.ts.map