export { TappSdk } from './library/TappSdk';
//# sourceMappingURL=index.d.ts.map